-- Assign admin role to the specified email
SELECT public.assign_admin_role('rsevidal117@gmail.com');