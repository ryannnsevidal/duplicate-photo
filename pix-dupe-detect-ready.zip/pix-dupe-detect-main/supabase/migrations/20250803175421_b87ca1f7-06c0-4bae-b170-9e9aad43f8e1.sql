-- Assign admin role to your email
SELECT public.assign_admin_role('rsevidal117@gmail.com');