#!/usr/bin/env bash
set -euo pipefail

CMD="${1:-all}"

case "$CMD" in
  unit)
    npm run test
    ;;
  cov|coverage)
    npm run test:cov
    ;;
  e2e)
    npx playwright install --with-deps >/dev/null
    npm run build
    npx http-server dist -p 5173 &
    PID=$!
    sleep 2
    npm run e2e || true
    kill $PID || true
    ;;
  debug)
    npx playwright install --with-deps >/dev/null
    npm run e2e:ui
    ;;
  auth)
    npx playwright install --with-deps >/dev/null
    npm run e2e -- -g "auth"
    ;;
  all|*)
    ./scripts/test-all.sh
    ;;
esac
