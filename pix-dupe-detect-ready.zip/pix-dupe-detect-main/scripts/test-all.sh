#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="logs"
mkdir -p "$LOG_DIR"
STAMP=$(date +"%Y-%m-%d-%H%M%S")

echo "🔧 Ensuring Playwright browsers..."
npx playwright install --with-deps >/dev/null

echo "🧪 Running unit/integration..."
npm run test | tee "$LOG_DIR/unit-$STAMP.txt"

echo "🧮 Coverage..."
npm run test:cov | tee "$LOG_DIR/coverage-$STAMP.txt"

echo "🏗️ Building app..."
npm run build

echo "🌐 Serving dist on :5173 and running E2E..."
npx http-server dist -p 5173 &
SERVE_PID=$!
sleep 2
set +e
npm run e2e | tee "$LOG_DIR/e2e-$STAMP.txt"
E2E_STATUS=${PIPESTATUS[0]}
set -e

kill $SERVE_PID || true

if [ "$E2E_STATUS" -ne 0 ]; then
  echo "❌ E2E failed. If available, open Playwright report: playwright-report/index.html"
  exit $E2E_STATUS
fi

echo "✅ All tests passed. Coverage: coverage/index.html, E2E: playwright-report/index.html"
